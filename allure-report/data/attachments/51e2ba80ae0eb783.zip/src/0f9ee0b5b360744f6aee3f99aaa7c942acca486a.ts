// spec: specs/selenium-practise-test-plan.md
// seed: tests/seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Catalog and Cart Edge Coverage', () => {
  test('Catalog and cart remain stable under rapid navigation', async ({ page }) => {
    await page.goto('https://rahulshettyacademy.com/seleniumPractise/#/');

    const brocolli = page.locator('.product').filter({ hasText: 'Brocolli - 1 Kg' });

    // 1. Rapidly add, remove, open, close, and reopen the cart while search changes.
    await brocolli.getByRole('spinbutton').fill('2');
    await brocolli.getByRole('button', { name: 'ADD TO CART' }).dblclick();

    await page.getByRole('link', { name: 'Cart' }).click();
    await expect(page.getByText('Brocolli - 1 Kg').last()).toBeVisible();

    await page.getByRole('link', { name: '×' }).click();
    await page.getByRole('link', { name: 'Cart' }).click();
    await expect(page.getByText('You cart is empty!')).toBeVisible();

    const search = page.getByRole('searchbox', { name: 'Search for Vegetables and Fruits' });
    await search.fill('xyz');
    await expect(page.getByRole('heading', { name: 'Sorry, no products matched your search!' })).toBeVisible();

    // 2. Verify summary/row consistency and no stale popover or negative amount.
    await search.fill('');
    await page.getByRole('link', { name: 'Cart' }).click();
    await expect(page.getByText('You cart is empty!')).toBeVisible();

    // 3. Use browser Back and Forward while populated.
    await brocolli.getByRole('button', { name: 'ADD TO CART' }).click();
    await page.goBack();
    await page.goForward();

    // 4. Verify navigation never submits an order and state remains consistent.
    await page.getByRole('link', { name: 'Cart' }).click();
    await expect(page.getByText('Brocolli - 1 Kg').last()).toBeVisible();
    await expect(page.getByRole('button', { name: 'PROCEED TO CHECKOUT' })).toBeVisible();
  });
});
