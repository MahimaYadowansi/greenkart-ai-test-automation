// spec: specs/selenium-practise-test-plan.md
// seed: tests/seed.spec.ts

import { test, expect } from '@playwright/test';

test.describe('Catalog and Cart Edge Coverage', () => {
  test('Mixed-cart removal and empty-cart recovery', async ({ page }) => {
    await page.goto('https://rahulshettyacademy.com/seleniumPractise/#/');

    const brocolli = page.locator('.product').filter({ hasText: 'Brocolli - 1 Kg' });
    const tomato = page.locator('.product').filter({ hasText: 'Tomato - 1 Kg' });
    const mushroom = page.locator('.product').filter({ hasText: 'Mushroom - 1 Kg' });

    // 1. Add Brocolli quantity 2, Tomato quantity 3, and Mushroom quantity 1.
    await brocolli.getByRole('spinbutton').fill('2');
    await tomato.getByRole('spinbutton').fill('3');
    await mushroom.getByRole('spinbutton').fill('1');

    await brocolli.getByRole('button', { name: 'ADD TO CART' }).click();
    await tomato.getByRole('button', { name: 'ADD TO CART' }).click();
    await mushroom.getByRole('button', { name: 'ADD TO CART' }).click();

    await page.getByRole('link', { name: 'Cart' }).click();

    // 2. Verify amount and each line total.
    await expect(page.getByText('Brocolli - 1 Kg').last()).toBeVisible();
    await expect(page.getByText('2 Nos.')).toBeVisible();
    await expect(page.getByText('₹ 240')).toBeVisible();

    await expect(page.getByText('Tomato - 1 Kg').last()).toBeVisible();
    await expect(page.getByText('3 Nos.')).toBeVisible();
    await expect(page.getByText('₹ 48')).toBeVisible();

    await expect(page.getByText('Mushroom - 1 Kg').last()).toBeVisible();
    await expect(page.getByText('1 Nos.')).toBeVisible();
    await expect(page.getByText('₹ 75')).toBeVisible();

    // 3. Remove every item and repeat attempts after empty.
    let removeLinks = page.getByRole('link', { name: '×' });
    while (await removeLinks.count()) {
      await removeLinks.first().click();
    }

    // 4. Verify 0 items and ₹0, no stale rows, and visible empty-cart recovery.
    await expect(page.getByText('You cart is empty!')).toBeVisible();
    await expect(page.getByText('Mushroom - 1 Kg')).not.toBeVisible();
    await expect(page.getByText('₹ 363')).not.toBeVisible();
  });
});
